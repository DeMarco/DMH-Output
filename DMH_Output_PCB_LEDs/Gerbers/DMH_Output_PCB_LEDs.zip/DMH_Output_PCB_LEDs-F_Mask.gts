%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-03-17T15:40:15-03:00*%
%TF.ProjectId,DMH_Output_PCB_LEDs,444d485f-4f75-4747-9075-745f5043425f,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-03-17 15:40:15*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.700000X1.700000*%
%ADD11C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,J29*%
X87500000Y-130000000D03*
%TD*%
D11*
%TO.C,H21*%
X75000000Y-88750000D03*
%TD*%
%TO.C,H23*%
X82000000Y-161000000D03*
%TD*%
%TO.C,H22*%
X75000000Y-127250000D03*
%TD*%
D10*
%TO.C,J0*%
X62500000Y-85000000D03*
%TD*%
M02*
