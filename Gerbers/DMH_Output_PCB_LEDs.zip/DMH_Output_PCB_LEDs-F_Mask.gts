%TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*%
%TF.CreationDate,2026-06-25T19:53:09+02:00*%
%TF.ProjectId,DMH_Output_PCB_LEDs,444d485f-4f75-4747-9075-745f5043425f,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-06-25 19:53:09*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.700000*%
%ADD11R,1.700000X1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,H22*%
X75000000Y-127250000D03*
%TD*%
%TO.C,H21*%
X75000000Y-88750000D03*
%TD*%
D11*
%TO.C,J29*%
X87500000Y-130000000D03*
%TD*%
%TO.C,J0*%
X62500000Y-85000000D03*
%TD*%
M02*
